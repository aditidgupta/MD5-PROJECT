import hashlib
filename = input("Enter filename from your list: ")
md5_hash = hashlib. md5()
a_file = open("filename", "rb")
content = a_file. read()
md5_hash. update(content)
digest = md5_hash. hexdigest()
# print(digest)

print(digest, file=open('output.txt','a'))
print("Adding md5checksum value to file.", file=open('output.txt','a'))